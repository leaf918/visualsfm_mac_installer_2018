Author : Pierre Moulon.
Usage : Required library files for PMVS2/CMVS.
 - boost (shared_ptr module)
 - jpeg
 - Graclus
 - CImg (header-only)
 - Eigen (header-only)
 - nlopt (CMakeLists.txt by Steven G. Johnson)
 - tinycthread
